package com.example.ch15_retrofit;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface NetworkService {
    @GET("api/users")
    Call<UserList> getUserList(@Query("page") String page);

    @GET
    Call<ResponseBody> getAvatarImage(@Url String url);
}
