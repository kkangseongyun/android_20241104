package com.example.ch15_retrofit;

import android.app.Application;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

//Application - 앱 프로세스 구동시 최초 싱글톤으로 유지..
public class MyApplication extends Application {
    NetworkService service;
    Retrofit retrofit;
    public MyApplication() {
        Retrofit.Builder builder = new Retrofit.Builder();
        builder.baseUrl("https://reqres.in/");
        builder.addConverterFactory(GsonConverterFactory.create());

        retrofit = builder.build();

        service = retrofit.create(NetworkService.class);
    }
}
