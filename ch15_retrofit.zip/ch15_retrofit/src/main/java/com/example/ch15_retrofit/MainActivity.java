package com.example.ch15_retrofit;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ch15_retrofit.databinding.ActivityMainBinding;
import com.example.ch15_retrofit.databinding.ItemMainBinding;

import java.util.ArrayList;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


class MyHolder extends RecyclerView.ViewHolder {
    ItemMainBinding binding;
    MyHolder(ItemMainBinding binding){
        super(binding.getRoot());
        this.binding = binding;
    }
}

class MyAdapter extends RecyclerView.Adapter<MyHolder> {
    MyApplication application;
    ArrayList<User> datas;
    MyAdapter(MyApplication application, ArrayList<User> datas){
        this.application = application;
        this.datas = datas;
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyHolder(ItemMainBinding.inflate(LayoutInflater.from(
                parent.getContext()
        ), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        User user = datas.get(position);
        holder.binding.id.setText(user.id);
        holder.binding.firstNameView.setText(user.firstName);
        holder.binding.lastNameView.setText(user.lastName);

        //이미지 데이터..
        if(user.avatar != null){
            //네트워킹... 이미지 다운로드..
            Call<ResponseBody> call = application.service.getAvatarImage(user.avatar);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if(response.isSuccessful()){
                        Bitmap bitmap = BitmapFactory.decodeStream(
                                response.body().byteStream());
                        holder.binding.avatarView.setImageBitmap(bitmap);
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {

                }
            });
        }
    }
}

public class MainActivity extends AppCompatActivity {

    ArrayList<User> userList = new ArrayList<>();
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        adapter = new MyAdapter((MyApplication) getApplication(), userList);
        binding.main.setLayoutManager(new LinearLayoutManager(this));
        binding.main.setAdapter(adapter);

        NetworkService service = ((MyApplication) getApplication()).service;

        Call<UserList> call = service.getUserList("1");
        call.enqueue(new Callback<UserList>() {
            @Override
            public void onResponse(Call<UserList> call, Response<UserList> response) {
                userList.addAll(response.body().data);
                //adapter 갱신..
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<UserList> call, Throwable t) {

            }
        });


    }
}