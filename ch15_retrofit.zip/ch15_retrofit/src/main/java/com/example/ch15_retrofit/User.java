package com.example.ch15_retrofit;

import com.google.gson.annotations.SerializedName;

//DTO
public class User {
    public String id;
    //서버 데이터 key 와 변수명이 다른경우에 어노테이션으로 명시..
    @SerializedName("first_name")
    public String firstName;
    @SerializedName("last_name")
    public String lastName;
    //회원 이미지 다운로드 url
    public String avatar;
}
