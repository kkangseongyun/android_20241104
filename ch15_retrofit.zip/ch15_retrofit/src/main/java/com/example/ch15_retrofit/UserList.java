package com.example.ch15_retrofit;


import java.util.ArrayList;

//DTO
public class UserList {
    //서버에서 넘어오는 모든 데이터를 변수로 선언할 필요 없다.. 필요한 것만..
    public String page;
    ArrayList<User> data;
}
